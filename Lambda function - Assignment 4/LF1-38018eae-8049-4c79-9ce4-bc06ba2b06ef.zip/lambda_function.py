from botocore.vendored import requests
import http
import json 
import boto3
import requests
from variables import *
import re

def lambda_handler(event, context):
    region ='us-east-1'
    service='es'
    tag=event['tags']
    client = boto3.client(service_name='lexv2-runtime', region_name=region, aws_access_key_id=B_ACCESS_KEY, aws_secret_access_key=B_SECRET_KEY)
    response = client.recognize_text(botId="WECYCIX6OM", botAliasId="YEKYKO7YDT",localeId="en_US",sessionId="test-session",text=tag) 
    content = response['messages'][0]["content"]
    tag = re.split('; |, |\*|\s+',content)[:3]

    params = { "query": { "terms": { "tags": tag, "boost": 1.0 } } }
    data = json.dumps(params)
    
    
    headers = {'content-type': 'application/json'}
    url = "https://search-posts-wjvdv53pafppjxv7dzqvkqhnba.us-east-1.es.amazonaws.com/posts/_search"
    r= requests.get(url=url,auth=(USER,PASS), data=data, headers=headers)
    response = r.json() 
    response = response["hits"]
    response = response["hits"]
    
    ids=[]
    for i in response:
        temp=i["_source"]
        ids.append(temp["id"])
    
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Posts')
    posts=[]
    for id in ids:
        response = table.get_item(
            Key={
                'id': id
            }
        )
        response = response['Item']
        posts.append(response['posts'])
    json_data = json.dumps({"posts": posts})
    messages = json_data[:3]
    sns_email(posts)
    
    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Headers":'*',
            "Access-Control-Allow-Origin": '*',
            "Access-Control-Allow-Methods": '*'
            
        },
        'body':json.dumps(json_data)
    }
    
def sns_email(messages):
    sns = boto3.client("sns", 
                   region_name="us-east-1", 
                   aws_access_key_id=B_ACCESS_KEY, 
                   aws_secret_access_key=B_SECRET_KEY)
    s="\n"
    messages = s.join(messages)
    response = sns.list_topics()
    topics = response["Topics"][0]
    topic_arn = topics["TopicArn"]
    
    sns.publish(TopicArn=topic_arn, 
            Message=messages, 
            Subject="Relevant Posts found" )