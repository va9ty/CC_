

ES_URL = "https://search-posts-wjvdv53pafppjxv7dzqvkqhnba.us-east-1.es.amazonaws.com"
ACCESS_KEY = "AKIA4RQ6CTWDKLTZFIE2"
SECRET_KEY = "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"
USER = "master_n"
PASS = "Ni1002130191!"

B_ACCESS_KEY="AKIA4RQ6CTWDNZ5EDZ6U"
B_SECRET_KEY="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"