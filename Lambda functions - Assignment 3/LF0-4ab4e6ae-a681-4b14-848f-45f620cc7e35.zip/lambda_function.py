import json
import boto3
import datetime
import uuid 


def lambda_handler(event, context):
    # TODO implement
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Posts')
    """
    resp = table.scan(AttributesToGet=['id'])
    last_index = resp['Items']
    a=[]
    for i in last_index: 
        a.append(i["id"])
    a.sort()
    last_index =int(a[-1]) +1
    """
    last_index = str(uuid.uuid4().hex) 
    question = event['questions']
    json_data= {}
    json_data['posts']= question
    json_data['id']=str(last_index)
    json_data['date']= str(datetime.datetime.now())
    
    response = table.put_item(Item=json_data)

    
    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Headers":'*',
            "Access-Control-Allow-Origin": '*',
            "Access-Control-Allow-Methods": '*'
            
        },
        'body': json.dumps(json_data)
    }
