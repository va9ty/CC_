from botocore.vendored import requests
import http
import json 
import boto3
import requests
from variables import *
import re

def lambda_handler(event, context):
    region ='us-east-1'
    service='es'
    
    
    url = "https://search-posts-wjvdv53pafppjxv7dzqvkqhnba.us-east-1.es.amazonaws.com/posts/_search"
    tag=event['tags']
    tag = re.split('; |, |\*|\s+',tag)   
    params = { "query": { "terms": { "tags": tag, "boost": 1.0 } } }
    data = json.dumps(params)
    
    headers = {'content-type': 'application/json'}
    r= requests.get(url=url,auth=(USER,PASS), data=data, headers=headers)
    response = r.json() 
    response = response["hits"]
    response = response["hits"]
    ids=[]
    for i in response:
        temp=i["_source"]
        ids.append(temp["id"])
    
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Posts')
    posts=[]
    for id in ids:
        response = table.get_item(
            Key={
                'id': id
            }
        )
        response = response['Item']
        posts.append(response['posts'])
    json_data = json.dumps({"posts": posts})

    
    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Headers":'*',
            "Access-Control-Allow-Origin": '*',
            "Access-Control-Allow-Methods": '*'
            
        },
        'body': json.dumps(json_data)
    }